import os


def deleteExistingJPGImages(folderPath: str) -> None:
    """Deletes all of the .jpg images in a given `folderPath`

    Args:
        folderPath (str): path to delete images from
    """
    fileList = [x for x in os.listdir(folderPath) if os.path.isfile(os.path.join(folderPath, x))]
    for fileName in fileList:
        if fileName.lower().endswith(".jpg"):
            file_path = os.path.join(folderPath, fileName)
            os.remove(file_path)
