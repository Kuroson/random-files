import json
from typing import Dict, List
from enum import Enum
import cv2
import numpy as np
import os


class ImageCategory(Enum):
    BACKGROUND = 0
    PENGUIN = 1
    TURTLE = 2


class ImageInfo:
    """Class that holds information about the image and its real category"""

    def __init__(self, imagePath: str, annotation: Dict[str, any]) -> None:
        """Creates an instance of ImageInfo

        Args:
            imagePath (str): relative path to image
            annotation (Dict[str, any]): dictionary (from JSON) containing information about the image
        """
        self.imagePath = imagePath
        self.image = cv2.imread(imagePath)
        self.image = cv2.cvtColor(self.image, cv2.COLOR_BGR2RGB)  # convert to RGB
        # possible resize operation
        self.category = ImageCategory(annotation["category_id"])
        self.area: int = annotation["area"]
        self.bbox: List[int] = annotation["bbox"]
        self.id: int = annotation["id"]

    def getImage(self) -> np.ndarray:
        """Get the image a 3D numpy array

        Returns:
            np.ndarray: in RGB format
        """
        return self.image

    def getID(self) -> int:
        """Get the original ID of the image

        Returns:
            int: id of image
        """
        return self.id

    def getCategory(self) -> ImageCategory:
        """Get the category of the image as an enum

        Returns:
            ImageCategory: category as enum
        """
        return self.category

    def getCategoryAsStr(self) -> str:
        """Gets the category of the image as a string

        Returns:
            str: category as string
        """
        if self.category == ImageCategory.BACKGROUND:
            return "background"
        elif self.category == ImageCategory.PENGUIN:
            return "penguin"
        else:
            return "turtle"

    def getCategoryAsID(self) -> int:
        """Gets the category of the image as an int id

        Returns:
            int: 1 for penguin, 2 for turtle
        """
        if self.category == ImageCategory.BACKGROUND:
            return 0
        elif self.category == ImageCategory.PENGUIN:
            return 1
        else:
            return 2

    def getBBox(self) -> List[int]:
        """Get bounding box

        Returns:
            List[int]: list of integers representing the bounding box coordinates in Pascal VOC format [xmin, ymin, xmax, ymax]
        """
        return self.bbox

    def getArea(self) -> int:
        """Get the area of the bounding box as an integer

        Returns:
            int: integer representing area of bounding box.
        """
        return self.area


class Dataset:
    def __init__(self, DATA_PATH="./data/", cropped=False) -> None:
        """Creates an instance of Dataset and parses all images in `DATA_PATH`

        Args:
            DATA_PATH (str, optional): Relative path to dataset to read. Defaults to "./data/".
        """
        self.DATA_PATH = DATA_PATH

        # === Setup Training Images data ===
        self.trainImages: Dict[int, ImageInfo] = {}
        self.trainingFileNames: list[str] = list(os.listdir(os.path.join(self.DATA_PATH, "train" if not cropped else "train_cropped")))
        self.trainingFileNames.sort()
        rawTrainingAnnotations = json.loads(
            open(os.path.join(self.DATA_PATH, "train_annotations")).read()
        )  # read in annotations and parse into list of dictionaries
        self.trainAnnotations: Dict[int, any] = {x["id"]: x for x in rawTrainingAnnotations}  # create dictionary of annotations
        # Read in images and create classes
        for index, fileName in enumerate(self.trainingFileNames):
            self.trainImages[int(index)] = ImageInfo(
                os.path.join(self.DATA_PATH, "train" if not cropped else "train_cropped", fileName), self.trainAnnotations[index]
            )

        # === Setup Valid Images data ===
        self.validImages: Dict[int, ImageInfo] = {}
        self.validFileNames: list[str] = list(os.listdir(os.path.join(self.DATA_PATH, "valid" if not cropped else "valid_cropped")))
        self.validFileNames.sort()
        rawValidAnnotations = json.loads(
            open(os.path.join(self.DATA_PATH, "valid_annotations")).read()
        )  # read in annotations and parse into list of dictionaries
        self.validAnnotations: Dict[int, any] = {x["id"]: x for x in rawValidAnnotations}  # create dictionary of annotations
        for index, fileName in enumerate(self.validFileNames):
            self.validImages[int(index)] = ImageInfo(
                os.path.join(self.DATA_PATH, "valid" if not cropped else "valid_cropped", fileName), self.validAnnotations[index]
            )

        print(f"Read in {len(self.trainImages)} training images")
        categoryCount = list(map(lambda x: x.getCategory(), list(self.trainImages.values())))
        print(f"\tThere are {categoryCount.count(ImageCategory.BACKGROUND)} background images")
        print(f"\tThere are {categoryCount.count(ImageCategory.PENGUIN)} penguin images")
        print(f"\tThere are {categoryCount.count(ImageCategory.TURTLE)} turtle images")
        print(f"Read in {len(self.validImages)} validation images")

    def getTrainImageById(self, id: int) -> ImageInfo:
        """Get original training image info by id

        Args:
            id (int): original id of image

        Returns:
            ImageInfo: Image information of image
        """
        return self.trainImages[id]

    def getValidImageById(self, id: int) -> ImageInfo:
        """Get original valid image info by id

        Args:
            id (int): original id of image

        Returns:
            ImageInfo: Image information of image
        """
        return self.validImages[id]

    def getAllTrainingImages(self) -> List[ImageInfo]:
        """Gets all of the training ImageInfo classes

        Returns:
            List[ImageInfo]: List of ImageInfo
        """
        return list(self.trainImages.values())

    def getAllTurtleTrainingImages(self) -> List[ImageInfo]:
        """Gets all of the training turtle ImageInfo classes

        Returns:
            List[ImageInfo]: List of ImageInfo turtles
        """
        return list(filter(lambda x: x.getCategory() == ImageCategory.TURTLE, list(self.trainImages.values())))

    def getAllPenguinTrainingImages(self) -> List[ImageInfo]:
        """Gets all of the training penguin ImageInfo classes

        Returns:
            List[ImageInfo]: List of ImageInfo penguins
        """
        return list(filter(lambda x: x.getCategory() == ImageCategory.PENGUIN, list(self.trainImages.values())))

    def getAllTrainingImagesAndAnnotations(self) -> tuple[np.ndarray[any, np.dtype], np.ndarray[any, np.dtype]]:
        """Gets all of the raw training images and annotations as a tuple

        Returns:
            tuple[np.ndarray[any, np.dtype], np.ndarray[any, np.dtype]]: (images, annotations)
        """
        annotations: List[str] = []
        images = []
        for image in self.trainImages.values():
            images.append(image.getImage())
            if image.getCategory() == ImageCategory.PENGUIN:
                annotations.append("penguin")
            else:
                annotations.append("turtle")
        return np.array(images), np.array(annotations)

    def getAllValidImages(self) -> List[ImageInfo]:
        """Gets all of the valid images as ImageInfos

        Returns:
            List[ImageInfo]: List of ImageInfo valid images
        """
        return list(self.validImages.values())

    def getAllValidImagesAndAnnotations(self) -> tuple[np.ndarray[any, np.dtype], np.ndarray[any, np.dtype]]:
        """Gets all of the raw valid images and annotations as a tuple

        Returns:
            tuple[np.ndarray[any, np.dtype], np.ndarray[any, np.dtype]]: (images, annotations)
        """
        annotations: List[str] = []
        images = []
        for image in self.validImages.values():
            images.append(image.getImage())
            if image.getCategory() == ImageCategory.PENGUIN:
                annotations.append("penguin")
            else:
                annotations.append("turtle")
        return np.array(images), np.array(annotations)
